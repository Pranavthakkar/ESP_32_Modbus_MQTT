# W5x00 Example

## Physical connection between ESP32 and W5500

* GPIO23 <--> MOSI
* GPIO19 <--> MISO
* GPIO18 <--> SCLK
* GPIO5  <--> SCS
