    #include "RMCS2304.h"
    #include "SoftwareSerial.h"
    #include "Arduino.h"

    byte Sprt;
    HardwareSerial *port;
    SoftwareSerial *softport;
    const byte MaxByteArraySize = 8;
    byte byteArray[MaxByteArraySize] = {0};

void RMCS2304::Serial0(long baudrate)
    {
        Serial.begin(baudrate);
    }
	
void RMCS2304::Serial_selection(byte x)
    {   
        if(x==0)  Sprt=0;
        if(x==1)  Sprt=1;
    }
     
void RMCS2304::begin(HardwareSerial *hport,long baudrate)
    {
        port=hport;
        if(port==&Serial)
        {
            Serial.println("error");
            Serial.println("Use other serial port");
            Serial.end();
        }
        else
            port->begin(baudrate);
    }

void RMCS2304::begin(SoftwareSerial *sport,long baudrate)
    {
        softport=sport;
        softport->begin(baudrate);
    }
	
byte RMCS2304::Enable_Analog_Mode(byte slave_id)
{
    byte j;
        j=WriteSingleRegister(slave_id,2,1);
        if(j==1) return 1;
        else return 0;
}

byte RMCS2304::Disable_Analog_Mode(byte slave_id)
{
    byte j;
        j=WriteSingleRegister(slave_id,2,0);
        if(j==1) return 1;
        else return 0;
}	
	
byte RMCS2304::Enable_Joystick_Mode(byte slave_id)
{
	byte j;
	j=WriteSingleRegister(slave_id,2,257);
	if(j==1) return 1;
	else return 0;
}

byte RMCS2304::Disable_Joystick_Mode(byte slave_id)
{ 
	 byte j;
	j=WriteSingleRegister(slave_id,2,256);
	if(j==1) return 1;
	else return 0;
}
byte RMCS2304::Enable_Digital_Mode(byte slave_id, byte dir)
    {
        int data; byte j;
        if(dir==0)   data=513;
        if(dir==1)   data=515;
        j=WriteSingleRegister(slave_id,2,data);
        if(j==1) return 1;
        else return 0;
    }
	
byte RMCS2304::Disable_Digital_Mode(byte slave_id,byte dir)
    { 
        int data; byte j;
        if(dir==0)   data=512;
        if(dir==1)   data=520;
        j=WriteSingleRegister(slave_id,2,data);
        if(j==1) return 1;
        else return 0;
    }
	  	

byte RMCS2304::Brake_Motor(byte slave_id,byte dir)
    { 
        int data; byte j;
        if(dir==0)   data=516;
        if(dir==1)   data=524;
        j=WriteSingleRegister(slave_id,2,data);
        if(j==1) return 1;
        else return 0;
    }
	
byte RMCS2304::Speed(byte slave_id, int SPEED)
    {  
        byte j;
        j=WriteSingleRegister(slave_id,14,SPEED);
        if(j==1) return 1;
        else return 0;
    }
 


byte RMCS2304::Acceleration(byte slave_id,int acceleration)
    {
        byte j;
        j= WriteSingleRegister(slave_id, 12, acceleration);
        if(j==1) return 1;
        else return 0;
    }

  
byte RMCS2304::WriteSingleRegister(byte slave_id, int address,unsigned int value)
    {   
        String response,res;byte j;
        String result=Modbus_string(slave_id,6,address,value);
      
        if(Sprt==0)
        {    
            port->print(result);
            delay(50);
            while(port->available())
           {response=port->readStringUntil('\n');}
            if(response=='\0')
            {Serial.println("CHECK YOUR SLAVE_ID"); return 0;}
            res=(response.substring(1,16));
            j=LRC(res,6);
            if(j==1) return 1;
            else return 0;
        }
        
        if(Sprt==1) 
        {
            softport->print(result);
            
            delay(50);
            while(softport->available())
            {response=softport->readStringUntil('\n');}
            if(response=='\0')
            {Serial.println("CHECK YOUR SLAVE_ID"); return 0;}
            res=(response.substring(1,16));
            j=LRC(res,6);
          
            if(j==1) return 1;
            else return 0;
        }
        
    }
    
String RMCS2304::Modbus_string(byte slave_id,byte FC,int address,unsigned int data)
    {
        byte sum =0;
        byte AddLoByte,AddHiByte,dataLoByte,dataHiByte;
        AddLoByte=AddHiByte=dataLoByte=dataHiByte=0;
        AddLoByte = (address & 0x00FF);
        AddHiByte = ((address & 0xFF00) >>8);
        dataLoByte = (data & 0x00FF);
        dataHiByte = ((data & 0xFF00) >>8);
        sum = 0;
        sum -= slave_id;
        sum -= FC;
        sum -= AddLoByte;
        sum -= AddHiByte;
        sum -= dataLoByte;
        sum -= dataHiByte;

        String SLAVE = print_hex(slave_id);
        String FCN = print_hex(FC);
        String AddHi = print_hex(AddHiByte);
        String AddLo = print_hex(AddLoByte);
        String dataHi = print_hex(dataHiByte);
        String dataLo = print_hex(dataLoByte);
        String LRC = print_hex(sum);
        String result=":"+ SLAVE+FCN+AddHi+AddLo+dataHi+dataLo+LRC+"\r\n";

        return result;
    }

String RMCS2304::print_hex(byte number)
    {
        String value = String(number,HEX);
        value.toUpperCase();
        if(value.length()==1){value = "0" + value;}
        return(value);
    }

String RMCS2304::ReadSingleRegister(byte slave_id, int address,unsigned int No_register) 
    {   
        String response,res; byte j;
        String result = Modbus_string(slave_id,3,address,No_register);
        if(Sprt==0)
        { 
            port->print(result);
            delay(20);
            
            while(port->available()>0)
            {
                response=(port->readStringUntil('\n'));
                Serial.print("<<");
            }
           
            res=response.substring(1,18);
            j=LRC(res,7);
            
            if(j==1) return(response);
            else return "0";

        }

        if(Sprt==1)
        {
            softport->print(result);
            delay(20);
            while(softport->available())
            {    
                response=(softport->readStringUntil('\n'));
                Serial.print("<<");
            }
            res=response.substring(1,18);
            j=LRC(res,7);
            if(j==1) return(response);
            else return "0";
        }
    }
    
byte RMCS2304:: WRITE_PARAMETER(byte slave_id,int INP_CONTROL_MODE,int acceleration,int SPEED)
{   
	byte W1,W7,W8;
    W1=W7=W8=0;
	
    W1=WriteSingleRegister(slave_id,2,INP_CONTROL_MODE);
    if(W1==1) {Serial.println("INP_CONTROL :          DONE");
         Serial.println("INP_MODE :             DONE");}
    else {Serial.print("error in writing parameters"); Serial.end();} 
    
    W7=Acceleration( slave_id, acceleration);
    if(W7==1) Serial.println("ACCELERATION :         DONE");
    else {Serial.print("error in writing parameters"); Serial.end();} 
    
    W8=Speed( slave_id,SPEED);
     if(W8==1) Serial.println("SPEED :                DONE");
    else {Serial.print("error in writing parameters"); Serial.end();}
    
    if(W1 & W7 & W8==1)
    {
		byte c;
		c=SAVE(slave_id);
		if(c==1) {Serial.println("ALL PERAMETER SET"); Serial.print("\n");}
		else Serial.print("NOT SAVED");
    }
}

byte RMCS2304::READ_PARAMETER(byte slave_id)
{  
	long int R1,R2,R3,R8,R9;
    R1=R2=R3=R8=R9=0;
    
	R1=READ_DEVICE_MODBUS_ADDRESS(slave_id);
    if(R1>=0)
    {Serial.print("DEVICE_MODBUS_ADDRESS: ");
    Serial.println(R1);}
    else 
    {Serial.print("ERROR IN READING"); 
    Serial.end();}
    
    R2=READ_INP_CONTROL_BYTE(slave_id);
    if(R2>=0)
    {
		Serial.print("INP_CONTROL_BYTE: ");
		Serial.println(R2);
	}
    else 
    {	Serial.println(R2);
        Serial.print("ERROR IN READING"); 
		Serial.end();
	}
    
    R3=READ_INP_MODE_BYTE(slave_id);
    if(R3>=0)
    {
		Serial.print("INP_MODE_BYTE: ");
		Serial.println(R3);
	}
    else 
    {
		Serial.print("ERROR IN READING"); 
		Serial.end();
	}
        
    R8=READ_TRP_ACL_WORD(slave_id);
    if(R8>=0)
    {
		Serial.print("TRP_ACL_WORD: ");
		Serial.println(R8);
	}
    else 
    {
		Serial.print("ERROR IN READING"); 
		Serial.end();
	}
    
    R9=READ_TRP_SPD_WORD(slave_id);
    if(R9>=0)
    {
		Serial.print("TRP_SPD_WORD: ");
		Serial.println(R9);
	}
    else 
    {
		Serial.print("ERROR IN READING"); 
		Serial.end();
	}
}


long int RMCS2304::READ_DEVICE_MODBUS_ADDRESS(byte slave_id) 
    {     
        String result,x; unsigned long int p;char a[9];int len;char *endptr;
        result=ReadSingleRegister( slave_id,1,1);
        x=result.substring(9,11);
        x.toCharArray(a,3);
        p=strtoul(a,&endptr,16);
      return(p);
    }
long int RMCS2304::READ_INP_CONTROL_BYTE(byte slave_id) 
    {     
         String result,x; unsigned long int p;char a[9];int len;char *endptr;
        result=ReadSingleRegister( slave_id,2,1);
        x=result.substring(9,11);
        x.toCharArray(a,3);
        p=strtoul(a,&endptr,16);
      return(p);
    }
long int RMCS2304::READ_INP_MODE_BYTE (byte slave_id) 
    {     
        String result,x; unsigned long int p;char a[9];int len;char *endptr;
        result=ReadSingleRegister( slave_id,3,1);
        x=result.substring(9,11);
        x.toCharArray(a,3);
        p=strtoul(a,&endptr,16);
      return(p);
    }

long int RMCS2304::READ_TRP_ACL_WORD (byte slave_id) 
    {     
        String result; unsigned long int q;
        result=ReadSingleRegister( slave_id,12,1);
        q = value( result);
      return(q);
    }
long int RMCS2304::READ_TRP_SPD_WORD(byte slave_id)
{
    String result; unsigned long int q;
        result=ReadSingleRegister( slave_id,14,1);
        q = value( result);
       
      return(q);
}

byte RMCS2304::SAVE(byte slave_id)
{
     byte j;
        int save=((slave_id<<8)|0xFF);
        j=WriteSingleRegister(slave_id,0,save);
        if(j==1) return 1;
        else return 0;
}
byte RMCS2304::RESET(byte slave_id)
{
    byte j,k;
		j=WriteSingleRegister(slave_id,4,0);
		if(j==1) 
			k=SAVE(slave_id);
		if(k==1) return 1;
		else return 0;
}


void RMCS2304::hexToBytes(byte *byteArray, char *hexString)
{
        byte currentByte = 0;  
        byte byteIndex = 0;

        for (byte charIndex = 0; charIndex < strlen(hexString); charIndex++)
        {
            bool oddCharIndex = charIndex & 1;
            if (!oddCharIndex)      // If the length is even
            {
            currentByte = nibble(hexString[charIndex]) << 4;  // Odd characters go into the high nibble
            }
            else
            {
            currentByte |= nibble(hexString[charIndex]);   // Odd characters go into low nibble
            byteArray[byteIndex++] = currentByte;
            currentByte = 0;
            }
        }
}

byte RMCS2304::nibble(char c)
{
  if (c >= '0' && c <= '9')
    return c - '0';

  if (c >= 'a' && c <= 'f')
    return c - 'a' + 10;

  if (c >= 'A' && c <= 'F')
    return c - 'A' + 10;

  return 0;  // Not a valid hexadecimal character
}

byte RMCS2304::LRC(String s,byte len)
{
        const char* ary=s.c_str();
        byte byteArray[MaxByteArraySize] = {0};
        hexToBytes(byteArray, const_cast<char*>(ary));
        byte sum;
        sum=0;
        for(int i=0;i<len;i++)
        {
            sum+=byteArray[i];
        }
        byte LRC=(~sum)+1;
        
		if(LRC==byteArray[len])  return 1;
        else
        { 
            if(Sprt==0)  port->end();
            if(Sprt==1)  softport->end();
            return 0;
        }
}


long int RMCS2304::value(String input)
{ 
	String x;char a[9];int len;char *endptr; long int p;
	len=input.length();

	x=input.substring(7,len-3);
	x.toCharArray(a,len-9);

	p=strtoul(a,&endptr,16);
	return p;
}
