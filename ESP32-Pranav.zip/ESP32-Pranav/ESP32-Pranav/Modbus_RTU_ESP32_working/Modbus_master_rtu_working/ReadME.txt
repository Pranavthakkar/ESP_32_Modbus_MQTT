this is working code for modbus master 31 july 7:3 PM

==============Panav RS485 cable tested